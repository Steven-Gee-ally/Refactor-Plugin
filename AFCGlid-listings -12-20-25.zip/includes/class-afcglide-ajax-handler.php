<?php
namespace AFCGlide\Listings;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AFCGlide Ajax Handler v3
 * Handles secure property submissions and media processing
 */
class AFCGlide_Ajax_Handler {

    public static function init() {
        $self = new self();
        // Hook for logged-in users
        add_action( 'wp_ajax_afcglide_submit_listing', [ $self, 'handle_submission' ] );
        // Hook for logged-out users (if applicable)
        add_action( 'wp_ajax_nopriv_afcglide_submit_listing', [ $self, 'handle_submission' ] );
    }

    public function handle_submission() {
        // 1. Security Check
        check_ajax_referer( 'afcglide_listing_nonce', 'security' );

        if ( empty( $_POST['prop_title'] ) ) {
            wp_send_json_error( [ 'message' => 'Title is required' ] );
        }

        // 2. Create the Post
        $post_data = [
            'post_title'   => sanitize_text_field( $_POST['prop_title'] ),
            'post_content' => wp_kses_post( $_POST['prop_desc'] ),
            'post_status'  => 'publish',
            'post_type'    => 'afcglide_listing',
            'post_author'  => get_current_user_id() ?: 1
        ];

        $post_id = wp_insert_post( $post_data );

        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Failed to create listing' ] );
        }

        // 3. Process Metadata
        $meta_fields = [
            '_listing_price'  => '_price',
            '_listing_beds'   => '_beds',
            '_listing_baths'  => '_baths',
            '_listing_sqft'   => '_sqft',
            '_gps_lat'        => '_lat',
            '_gps_lng'        => '_lng',
            '_agent_name'     => '_agent_name',
            '_agent_phone'    => '_agent_phone',
            '_agent_whatsapp' => '_agent_whatsapp',
            '_agent_email'    => '_agent_email'
        ];

        foreach ( $meta_fields as $meta_key => $post_key ) {
            if ( isset( $_POST[$post_key] ) ) {
                update_post_meta( $post_id, $meta_key, sanitize_text_field( $_POST[$post_key] ) );
            }
        }

        // 4. Process Amenities (Array)
        if ( ! empty( $_POST['amenities'] ) && is_array( $_POST['amenities'] ) ) {
            update_post_meta( $post_id, '_listing_amenities', array_map( 'sanitize_text_field', $_POST['amenities'] ) );
        }

        // 5. Handle Media Uploads (The tricky part)
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );

        // Hero Image
        if ( ! empty( $_FILES['hero_image'] ) ) {
            $hero_id = media_handle_upload( 'hero_image', $post_id );
            if ( ! is_wp_error( $hero_id ) ) {
                update_post_meta( $post_id, '_hero_image_id', $hero_id );
                set_post_thumbnail( $post_id, $hero_id );
            }
        }

        // Stack Images (Gallery)
        if ( ! empty( $_FILES['property_stack'] ) ) {
            $stack_ids = [];
            $files = $_FILES['property_stack'];
            foreach ( $files['name'] as $key => $value ) {
                if ( $files['name'][$key] ) {
                    $file = [
                        'name'     => $files['name'][$key],
                        'type'     => $files['type'][$key],
                        'tmp_name' => $files['tmp_name'][$key],
                        'error'    => $files['error'][$key],
                        'size'     => $files['size'][$key]
                    ];
                    $_FILES['temp_upload'] = $file;
                    $attach_id = media_handle_upload( 'temp_upload', $post_id );
                    if ( ! is_wp_error( $attach_id ) ) {
                        $stack_ids[] = $attach_id;
                    }
                }
            }
            update_post_meta( $post_id, '_property_stack_ids', $stack_ids );
            update_post_meta( $post_id, '_property_slider_ids', $stack_ids ); // Sync for now
        }

        wp_send_json_success( [ 'message' => 'Listing Published!', 'url' => get_permalink( $post_id ) ] );
    }
}