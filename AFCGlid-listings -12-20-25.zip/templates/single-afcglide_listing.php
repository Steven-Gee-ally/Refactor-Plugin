<?php
/**
 * AFCGlide Single Listing Template - BILINGUAL ASTRA BYPASS
 */

// 1. KILL ASTRA WRAPPERS
remove_all_actions( 'astra_content_before' );
remove_all_actions( 'astra_content_after' );
remove_all_actions( 'astra_entry_before' );
remove_all_actions( 'astra_entry_after' );
remove_all_actions( 'astra_entry_content_before' );
remove_all_actions( 'astra_entry_content_after' );
add_filter( 'astra_page_layout', function() { return 'no-sidebar'; }, 9999 );
add_filter( 'astra_get_content_layout', function() { return 'plain-container'; }, 9999 );

// 2. DATA PULL
$post_id   = get_the_ID();
$author_id = get_post_field( 'post_author', $post_id );
$price      = get_post_meta( $post_id, '_listing_price', true );
$lat        = get_post_meta( $post_id, '_gps_lat', true );
$lng        = get_post_meta( $post_id, '_gps_lng', true );
$amenities  = get_post_meta( $post_id, '_listing_amenities', true ) ?: [];
$agent_name  = get_the_author_meta( 'display_name', $author_id );
$agent_phone = get_user_meta( $author_id, 'agent_phone', true );
$agent_photo = get_post_meta( $post_id, '_agent_photo_id', true ); 
$agent_logo  = get_post_meta( $post_id, '_agency_logo_id', true ); 
$stack_ids   = get_post_meta($post_id, '_property_stack_ids', true) ?: [];

// 3. BILINGUAL LOGIC
$current_lang = get_locale(); 
$is_spanish = (strpos($current_lang, 'es') !== false);
$amenity_labels = [
    'ocean_view' => $is_spanish ? '🌊 Vista al Mar' : '🌊 Ocean View',
    'beach_front' => $is_spanish ? '🏖️ Frente a la Playa' : '🏖️ Beach Front',
    'mountain_view' => $is_spanish ? '⛰️ Vista a la Montaña' : '⛰️ Mountain View',
    'jungle_setting' => $is_spanish ? '🐒 Entorno de Selva' : '🐒 Jungle Setting',
    'infinity_pool' => $is_spanish ? '♾️ Piscina Infinita' : '♾️ Infinity Pool',
    'gourmet_kitchen' => $is_spanish ? '👨‍🍳 Cocina de Chef' : '👨‍🍳 Gourmet Kitchen',
    'security_24_7' => $is_spanish ? '👮 Seguridad 24/7' : '👮 24/7 Security',
    'guest_house' => $is_spanish ? '🏠 Casa de Huéspedes' : '🏠 Guest House',
    'high_speed_fiber' => $is_spanish ? '📶 Fibra Óptica' : '📶 High-Speed Fiber',
];
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
    <style>
        .ast-container, .site-content, #primary { max-width: 100% !important; padding: 0 !important; margin: 0 !important; }
        .afcglide-single-root { max-width: 1400px; margin: 0 auto; padding: 0 20px; font-family: 'Inter', sans-serif; }
    </style>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header style="background: #fff; border-bottom: 1px solid #e2e8f0; padding: 20px 0;">
    <div style="max-width: 1400px; margin: 0 auto; padding: 0 20px; display: flex; justify-content: space-between;">
        <a href="<?php echo home_url(); ?>" style="font-size: 24px; font-weight: 800; text-decoration: none; color: #1e293b;"><?php bloginfo( 'name' ); ?></a>
        <a href="<?php echo home_url( '/listings/' ); ?>" style="color: #64748b; text-decoration: none;"><?php echo $is_spanish ? '← Volver' : '← Back'; ?></a>
    </div>
</header>
<div class="afcglide-single-root">
    <section style="display: flex; gap: 10px; margin-top: 20px; height: 600px;">
        <div style="flex: 2; position: relative; overflow: hidden; border-radius: 12px 0 0 12px; background: #eee;">
            <?php if ( has_post_thumbnail() ) : ?>
                <a href="<?php echo get_the_post_thumbnail_url($post_id, 'full'); ?>" class="glightbox" data-gallery="prop">
                    <?php the_post_thumbnail('full', ['style' => 'width:100%; height:100%; object-fit:cover;']); ?>
                </a>
            <?php endif; ?>
            <div style="position: absolute; bottom: 20px; left: 20px; background: rgba(0,0,0,0.8); color: #fff; padding: 10px 20px; border-radius: 5px; font-size: 24px; font-weight: 800;">
                $<?php echo number_format((float)$price); ?>
            </div>
        </div>
        <div style="flex: 1; display: flex; flex-direction: column; gap: 10px;">
            <?php for($i=0; $i<3; $i++): ?>
                <div style="flex: 1; overflow: hidden; background: #f1f5f9; border-radius: <?php echo ($i==0)?'0 12px 0 0':(($i==2)?'0 0 12px 0':'0'); ?>;">
                    <?php if(!empty($stack_ids[$i])) : 
                        $url = wp_get_attachment_url($stack_ids[$i]); ?>
                        <a href="<?php echo $url; ?>" class="glightbox" data-gallery="prop">
                            <img src="<?php echo $url; ?>" style="width:100%; height:100%; object-fit:cover;">
                        </a>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>
        </div>
    </section>
    <div style="display: grid; grid-template-columns: 1.6fr 1fr; gap: 60px; margin: 40px 0;">
        <div>
            <h1><?php the_title(); ?></h1>
            <?php the_content(); ?>
        </div>
        <div>
            <div style="background: #f8fafc; padding: 20px; border-radius: 12px;">
                <h3>Features</h3>
                <?php foreach ( $amenities as $slug ) : ?>
                    <div>✦ <?php echo esc_html($slug); ?></div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php if($lat && $lng): ?>
    <section style="height: 400px; margin-bottom: 40px;">
        <iframe width="100%" height="100%" frameborder="0" src="https://maps.google.com/maps?q=<?php echo $lat; ?>,<?php echo $lng; ?>&hl=es&z=15&output=embed"></iframe>
    </section>
    <?php endif; ?>
</div>
<?php wp_footer(); ?>
</body>
</html>