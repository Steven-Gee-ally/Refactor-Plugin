<?php
namespace AFCGlide\Listings;

/**
 * Plugin Name: AFCGlide Listings
 * Description: Real Estate Listings - Full Build (Optimized v3.6.6)
 * Version: 3.6.6-STEVO-LIVE
 * Author: Stevo
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'AFCG_VERSION', '3.6.6' );
define( 'AFCG_PATH', plugin_dir_path( __FILE__ ) );
define( 'AFCG_URL', plugin_dir_url( __FILE__ ) );

/**
 * Main Plugin Bootstrap Class
 */
class AFCGlide_Plugin {
    
    private static $workers = [
        'includes/helpers/class-validator.php',
        'includes/helpers/class-sanitizer.php',
        'includes/helpers/class-message-helper.php',
        'includes/helpers/class-upload-helper.php',
        'includes/helpers/helpers.php',
        'includes/class-cpt-tax.php',
        'includes/class-afcglide-metaboxes.php',
        'includes/class-afcglide-settings.php',
        'includes/class-afcglide-templates.php',
        'includes/class-afcglide-block-manager.php',
        'includes/class-afcglide-admin-assets.php',
        'includes/class-afcglide-public.php',
        'includes/class-afcglide-ajax-handler.php',
        'includes/class-afcglide-user-profile.php',
        'includes/class-afcglide-shortcodes.php',
        'submission/class-submission-auth.php',
        'submission/class-submission-listing.php',
        'submission/class-submission-files.php',
    ];
    
    private static $core_classes = [
        'AFCGlide_CPT_Tax',
        'AFCGlide_Metaboxes',
        'AFCGlide_Shortcodes',
        'AFCGlide_Public',
        'AFCGlide_Settings',
        'AFCGlide_Ajax_Handler',
        'AFCGlide_Block_Manager',
        'AFCGlide_Admin_Assets',
        'AFCGlide_User_Profile',
        'AFCGlide_Templates',
    ];
    
    private static $submission_classes = [
        'Submission_Auth',
        'Submission_Listing',
        'Submission_Files',
    ];

    public static function init() {
        self::load_files();
        add_action( 'init', [ __CLASS__, 'initialize_classes' ], 5 );
        add_action( 'admin_menu', [ __CLASS__, 'clean_admin_menu' ], 999 );
        
        register_activation_hook( __FILE__, [ __CLASS__, 'on_activation' ] );
    }

    public static function clean_admin_menu() {
        remove_submenu_page( 'edit.php?post_type=afcglide_listing', 'post-new.php?post_type=afcglide_listing' );
    }

    private static function load_files() {
        foreach ( self::$workers as $worker ) {
            $file = AFCG_PATH . $worker;
            if ( file_exists( $file ) ) {
                require_once $file;
            }
        }
    }
    
    public static function initialize_classes() {
        if ( class_exists( __NAMESPACE__ . '\\AFCGlide_CPT_Tax' ) ) {
            AFCGlide_CPT_Tax::init();
        }
        foreach ( self::$core_classes as $class ) {
            if ( $class === 'AFCGlide_CPT_Tax' ) continue;
            self::init_class( $class, __NAMESPACE__ );
        }
    }
    
    private static function init_class( $class, $namespace ) {
        $full_class = $namespace . '\\' . $class;
        if ( class_exists( $full_class ) && method_exists( $full_class, 'init' ) ) {
            $full_class::init();
        }
    }
    
    public static function on_activation() {
        flush_rewrite_rules();
    }
}

// 1. BOOT THE SYSTEM
AFCGlide_Plugin::init();

// 2. THE BRUTE FORCE BYPASS (Astra Killer)
add_filter( 'template_include', function( $template ) {
    global $post;

    // Direct check for our specific listing type
    if ( is_single() && isset($post->post_type) && $post->post_type === 'afcglide_listing' ) {
        $custom_path = plugin_dir_path( __FILE__ ) . 'templates/single-afcglide_listing.php';
        
        if ( file_exists( $custom_path ) ) {
            return $custom_path;
        }
    }
    return $template;
}, 10000 ); // Highest priority to override Astra settings