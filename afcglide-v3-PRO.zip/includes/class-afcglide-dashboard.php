<?php
namespace AFCGlide\Admin; 

use AFCGlide\Core\Constants as C; // Use our central brain

if ( ! defined( 'ABSPATH' ) ) exit;

class AFCGlide_Dashboard {
    
    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'register_welcome_page' ] );
        add_action( 'admin_init', [ __CLASS__, 'handle_protocol_execution' ] );
        add_action( 'admin_init', [ __CLASS__, 'handle_agent_creation' ] );
        add_action( 'admin_init', [ __CLASS__, 'handle_agent_password_reset' ] );
        // AJAX toggle for the dashboard switches
        add_action( 'wp_ajax_afc_toggle_security', [ __CLASS__, 'ajax_toggle_security' ] );
    }

    public static function register_welcome_page() {
        $is_broker = current_user_can(C::CAP_MANAGE);
        $system_label = C::get_option(C::OPT_SYSTEM_LABEL, 'AFCGlide');
        $capability = 'create_afc_listings'; // Your custom cap

        add_menu_page( 
            $system_label . ' Hub', 
            $system_label, 
            $capability, 
            C::MENU_DASHBOARD, 
            [ __CLASS__, 'render_welcome_screen' ], 
            'dashicons-dashboard', 
            5.9 
        );

        add_submenu_page( C::MENU_DASHBOARD, 'Hub Overview', '📊 Hub Overview', $capability, C::MENU_DASHBOARD, [ __CLASS__, 'render_welcome_screen' ] );

        // Dynamic Menu Labeling based on Role
        $inv_label = $is_broker ? '💼 Global Inventory' : '💼 My Portfolio';
        add_submenu_page( C::MENU_DASHBOARD, $inv_label, $inv_label, $capability, 'edit.php?post_type=' . C::POST_TYPE );

        add_submenu_page( C::MENU_DASHBOARD, 'Add New Asset', '🛸 Add New Asset', $capability, 'post-new.php?post_type=' . C::POST_TYPE );
        add_submenu_page( C::MENU_DASHBOARD, 'System Manual', '📘 System Manual', $capability, 'afcglide-manual', [ __CLASS__, 'render_manual_page' ] );
    }

    /**
     * Protocol Execution Logic
     * Synchronized with Settings Page v4.7.2
     */
    public static function handle_protocol_execution() {
        if ( isset($_POST['afc_execute_protocols']) && check_admin_referer('afc_protocols', 'afc_protocols_nonce') ) {
            
            // We use the central constants to ensure the Settings Page and Dashboard are mirrors
            update_option(C::OPT_GLOBAL_LOCKDOWN, isset($_POST['global_lockdown']) ? '1' : '0');
            update_option(C::OPT_IDENTITY_SHIELD, isset($_POST['identity_shield']) ? '1' : '0');
            
            wp_redirect( admin_url('admin.php?page=' . C::MENU_DASHBOARD . '&protocols=executed') );
            exit;
        }
    }

    /**
     * Rapid Agent Onboarding Logic
     */
    public static function handle_agent_creation() {
        if ( isset($_POST['afc_rapid_add_agent']) && check_admin_referer('afc_rapid_agent', 'afc_rapid_agent_nonce') ) {
            if ( ! current_user_can(C::CAP_MANAGE) ) return;

            $user_login = sanitize_user($_POST['agent_user']);
            $user_email = sanitize_email($_POST['agent_email']);
            $user_pass  = $_POST['agent_pass'];

            if ( username_exists($user_login) || email_exists($user_email) ) {
                wp_redirect( admin_url('admin.php?page=' . C::MENU_DASHBOARD . '&agent_error=exists') );
                exit;
            }

            $user_id = wp_create_user($user_login, $user_pass, $user_email);
            if ( ! is_wp_error($user_id) ) {
                $user = new \WP_User($user_id);
                $user->set_role('listing_agent');
                
                // Save specific Agent meta
                update_user_meta($user_id, C::USER_PHONE, sanitize_text_field($_POST['agent_phone'] ?? ''));
                
                set_transient('afc_last_created_agent', [
                    'user' => $user_login,
                    'pass' => $user_pass,
                    'url'  => wp_login_url()
                ], 300);

                wp_redirect( admin_url('admin.php?page=' . C::MENU_DASHBOARD . '&agent_added=1') );
                exit;
            }
        }
    }

    public static function render_welcome_screen() {
        $current_user = wp_get_current_user();
        $is_broker = current_user_can(C::CAP_MANAGE);
        $display_name = strtoupper($current_user->first_name ?: $current_user->display_name);
        $system_label = C::get_option(C::OPT_SYSTEM_LABEL, 'AFCGlide');
        $primary_color = C::get_option(C::OPT_PRIMARY_COLOR, '#6366f1');
        ?>

        <style>
            .afc-control-center { padding: 20px; font-family: 'Inter', -apple-system, sans-serif; }
            .afc-top-bar { 
                display: flex; justify-content: space-between; 
                background: #1e293b; color: white; padding: 15px 25px; 
                border-radius: 12px; margin-bottom: 30px; font-size: 11px; letter-spacing: 1px;
            }
            .afc-section { 
                background: white; border-radius: 16px; padding: 35px; 
                margin-bottom: 30px; border: 1px solid #e2e8f0; 
                box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
            }
            .afc-section-header h2 { font-size: 16px; font-weight: 900; margin-bottom: 25px; letter-spacing: -0.5px; }
            
            /* Toggle Styles matching Settings UI */
            .afc-switch { position: relative; display: inline-block; width: 44px; height: 22px; }
            .afc-switch input { opacity: 0; width: 0; height: 0; }
            .switch-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #cbd5e1; transition: .4s; border-radius: 34px; }
            .switch-slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
            input:checked + .switch-slider { background-color: #ef4444; }
            input:checked + .switch-slider:before { transform: translateX(22px); }

            .afc-execute-btn {
                background: #1e293b; color: white; border: none; padding: 12px 25px; 
                border-radius: 10px; font-weight: 800; cursor: pointer; transition: 0.3s;
            }
            .afc-execute-btn:hover { transform: translateY(-2px); box-shadow: 0 10px 15px rgba(0,0,0,0.1); }
        </style>

        <div class="afc-control-center">
            <div class="afc-top-bar">
                <div>OPERATOR: <span style="color:<?php echo esc_attr($primary_color); ?>;"><?php echo esc_html($display_name); ?></span></div>
                <div style="font-weight:900;"><?php echo esc_html($system_label); ?> CORE INFRASTRUCTURE</div>
                <div>NODE: <span style="font-weight:900;">v5.0.1-STABLE</span></div>
            </div>

            <?php 
                if (class_exists('\AFCGlide\Reporting\AFCGlide_Scoreboard')) {
                    echo \AFCGlide\Reporting\AFCGlide_Scoreboard::render_scoreboard( $is_broker ? null : $current_user->ID ); 
                }
            ?>

            <?php if ($is_broker) : ?>
            <div class="afc-section" style="border-left: 6px solid #8b5cf6;">
                <div class="afc-section-header"><h2 style="color:#5b21b6;">🚀 RAPID AGENT ONBOARDING</h2></div>
                
                <?php if ( isset($_GET['agent_added']) && $guide = get_transient('afc_last_created_agent') ) : ?>
                    <div style="background:#f5f3ff; border:2px dashed #8b5cf6; padding:25px; border-radius:12px; margin-bottom:25px;">
                        <h3 style="color:#5b21b6; margin-top:0; font-size:14px;">AGENT ACCESS GUIDE READY</h3>
                        <textarea id="afc_guide_text" readonly style="width:100%; height:90px; padding:12px; border-radius:8px; border:1px solid #ddd6fe; font-family:monospace; font-size:12px; margin:10px 0;">
Access Credentials for <?php echo esc_html($system_label); ?>
URL: <?php echo esc_url($guide['url']); ?>
User: <?php echo esc_html($guide['user']); ?>
Pass: <?php echo esc_html($guide['pass']); ?>
                        </textarea>
                        <button type="button" onclick="afcCopyGuide()" id="afc_copy_btn" class="afc-execute-btn" style="background:#8b5cf6;">COPY TO CLIPBOARD</button>
                    </div>
                <?php endif; ?>

                <form method="post" action="">
                    <?php wp_nonce_field('afc_rapid_agent', 'afc_rapid_agent_nonce'); ?>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                        <input type="text" name="agent_user" required placeholder="Username" style="padding:12px; border-radius:8px; border:1px solid #cbd5e1;">
                        <input type="email" name="agent_email" required placeholder="Email Address" style="padding:12px; border-radius:8px; border:1px solid #cbd5e1;">
                        <input type="text" name="agent_pass" required placeholder="Password" style="padding:12px; border-radius:8px; border:1px solid #cbd5e1;">
                        <button type="submit" name="afc_rapid_add_agent" class="afc-execute-btn" style="background:<?php echo esc_attr($primary_color); ?>;">CREATE AGENT</button>
                    </div>
                </form>
            </div>

            <div class="afc-section" style="border-left: 6px solid #ef4444;">
                <div class="afc-section-header"><h2 style="color:#b91c1c;">🔒 SECURITY PROTOCOLS</h2></div>
                <form method="post" action="">
                    <?php wp_nonce_field('afc_protocols', 'afc_protocols_nonce'); ?>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div style="display:flex; gap:40px;">
                            <div style="display:flex; align-items:center; gap:12px;">
                                <label class="afc-switch"><input type="checkbox" name="global_lockdown" value="1" <?php checked(C::get_option(C::OPT_GLOBAL_LOCKDOWN), '1'); ?>><span class="switch-slider"></span></label>
                                <span style="font-size:13px; font-weight:800; color:#991b1b;">GLOBAL LOCKDOWN</span>
                            </div>
                            <div style="display:flex; align-items:center; gap:12px;">
                                <label class="afc-switch"><input type="checkbox" name="identity_shield" value="1" <?php checked(C::get_option(C::OPT_IDENTITY_SHIELD), '1'); ?>><span class="switch-slider"></span></label>
                                <span style="font-size:13px; font-weight:800; color:#991b1b;">IDENTITY SHIELD</span>
                            </div>
                        </div>
                        <button type="submit" name="afc_execute_protocols" class="afc-execute-btn" style="background:#ef4444;">DEPLOY PROTOCOLS</button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>

        <script>
        function afcCopyGuide() {
            var copyText = document.getElementById("afc_guide_text");
            copyText.select();
            document.execCommand("copy");
            document.getElementById("afc_copy_btn").innerText = "COPIED!";
        }
        </script>
        <?php
    }

    public static function render_manual_page() { echo '<div class="wrap"><h1>Manual</h1></div>'; }
}