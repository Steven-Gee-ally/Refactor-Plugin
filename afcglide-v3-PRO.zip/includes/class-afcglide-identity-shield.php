<?php
namespace AFCGlide\Admin;

use AFCGlide\Core\Constants;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AFCGlide Identity Shield
 * The "Bouncer": Enforces Global Network Lockdown and Role Security.
 */
class AFCGlide_Identity_Shield {

    public static function init() {
        // Run early on admin initialization
        add_action( 'admin_init', [ __CLASS__, 'enforce_lockdown' ] );
    }

    /**
     * Enforce Global Network Lockdown
     * Redirects non-privileged users if the Master Switch is ON.
     */
    public static function enforce_lockdown() {
        // 1. Check if we are doing an AJAX call (don't break those yet)
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;

        // 2. Is Lockdown actually enabled in your new Settings page?
        $is_locked = get_option( Constants::OPT_LOCKDOWN, 0 );
        if ( ! $is_locked ) return;

        // 3. Who is trying to enter?
        // If they can manage options (Admin) or have the specific Managing Broker cap, let them in.
        if ( current_user_can( 'manage_options' ) || current_user_can( Constants::CAP_MANAGE ) ) {
            return;
        }

        // 4. Otherwise, it's a regular Agent. Redirect to home with a notice.
        $system_label = get_option( Constants::OPT_SYSTEM_LABEL, 'Synergy' );
        
        wp_logout(); // Optional: Force logout for maximum "Lockdown"
        wp_safe_redirect( add_query_arg( 'afc_status', 'lockdown', home_url() ) );
        exit;
    }
}