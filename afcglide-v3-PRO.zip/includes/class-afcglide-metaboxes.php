<?php
namespace AFCGlide\Listings;

use AFCGlide\Core\Constants as C;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AFCGlide Metaboxes v4.5 - Executive Edition
 * Purpose: Centralized administration for high-end real estate assets.
 * Standards: PSR-12, Strict Type Casting, Enterprise Security.
 */
class AFCGlide_Metaboxes {

    public static function init() {
        add_action( 'init', [ __CLASS__, 'register_post_content_support' ] );
        add_action( 'add_meta_boxes', [ __CLASS__, 'add_metaboxes' ] );
        add_action( 'save_post', [ __CLASS__, 'save_metaboxes' ], 10, 2 );
        add_action( 'admin_notices', [ __CLASS__, 'render_admin_notices' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_assets' ] );
    }

    public static function register_post_content_support() {
        add_post_type_support( C::POST_TYPE, 'editor' );
    }

    public static function enqueue_admin_assets( $hook ) {
        if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ] ) ) return;
        
        $screen = get_current_screen();
        if ( $screen->post_type !== C::POST_TYPE ) return;

        wp_enqueue_media();
        wp_enqueue_style( 'afc-admin-ui', plugin_dir_url(__FILE__) . 'css/afc-admin.css', [], '1.1.0' );
        wp_enqueue_script(
            'afc-metaboxes-js',
            plugin_dir_url(__FILE__) . 'js/afc-metaboxes.js',
            ['jquery', 'jquery-ui-sortable'],
            '1.1.0',
            true
        );
    }

    public static function add_metaboxes() {
        // Clean the workspace: Focus the agent only on premium controls
        remove_meta_box( 'submitdiv', C::POST_TYPE, 'side' );
        remove_meta_box( 'postimagediv', C::POST_TYPE, 'side' );
        remove_meta_box( 'authordiv', C::POST_TYPE, 'side' );

        $screen = C::POST_TYPE;
        
        // Primary Content Area
        add_meta_box( 'afc_intro', '📝 1. Property Description', [ __CLASS__, 'render_intro_metabox' ], $screen, 'normal', 'high' );
        add_meta_box( 'afc_details', '🏠 2. Property Specifications', [ __CLASS__, 'render_details_metabox' ], $screen, 'normal', 'high' );
        add_meta_box( 'afc_media_hub', '📸 3. Visual Command Center', [ __CLASS__, 'render_media_metabox' ], $screen, 'normal', 'high' );
        add_meta_box( 'afc_location_v2', '📍 4. Location & GPS', [ __CLASS__, 'render_location_metabox' ], $screen, 'normal', 'high' );
        add_meta_box( 'afc_amenities', '💎 5. Property Features', [ __CLASS__, 'render_amenities_metabox' ], $screen, 'normal', 'high' );
        add_meta_box( 'afc_agent', '👤 6. Agent Branding', [ __CLASS__, 'render_agent_metabox' ], $screen, 'normal', 'high' );
        add_meta_box( 'afc_intelligence', '📊 7. Asset Intelligence', [ __CLASS__, 'render_intelligence_metabox' ], $screen, 'normal', 'high' );
        
        // Control Sidebar
        add_meta_box( 'afc_publish_box', '🚀 Global Broadcast Control', [ __CLASS__, 'render_publish_metabox' ], $screen, 'side', 'high' );
    }

    /* =========================================================
        RENDER METHODS
    ========================================================= */

    public static function render_intro_metabox( $post ) {
        wp_nonce_field( C::NONCE_META, 'afc_listing_nonce' );
        $intro = C::get_meta( $post->ID, C::META_INTRO );
        $narrative = C::get_meta( $post->ID, C::META_NARRATIVE );
        ?>
        <div class="afc-metabox-content">
            <div class="afc-field">
                <label class="afc-label">Property Headline</label>
                <input type="text" name="_listing_intro_text" value="<?php echo esc_attr( $intro ); ?>" class="afc-input-large" placeholder="e.g. Stunning Modern Villa in the Hills">
            </div>
            <div class="afc-field">
                <label class="afc-label">Property Narrative</label>
                <?php wp_editor( $narrative, 'afc_listing_narrative', [
                    'textarea_name' => '_listing_narrative',
                    'media_buttons' => false,
                    'textarea_rows' => 10,
                    'tinymce'       => ['toolbar1'=>'formatselect,bold,italic,bullist,numlist,link,unlink,blockquote']
                ]); ?>
            </div>
        </div>
        <?php
    }

    public static function render_details_metabox( $post ) {
        $price = C::get_meta( $post->ID, C::META_PRICE );
        $beds  = C::get_meta( $post->ID, C::META_BEDS );
        $baths = C::get_meta( $post->ID, C::META_BATHS );
        $sqft  = C::get_meta( $post->ID, C::META_SQFT );
        ?>
        <div class="afc-metabox-content afc-grid-4">
            <div class="afc-field">
                <label class="afc-label">Price (USD)</label>
                <input type="number" name="_listing_price" value="<?php echo esc_attr($price); ?>" class="afc-input">
            </div>
            <div class="afc-field">
                <label class="afc-label">Beds</label>
                <input type="number" name="_listing_beds" value="<?php echo esc_attr($beds); ?>" class="afc-input">
            </div>
            <div class="afc-field">
                <label class="afc-label">Baths</label>
                <input type="number" step="0.5" name="_listing_baths" value="<?php echo esc_attr($baths); ?>" class="afc-input">
            </div>
            <div class="afc-field">
                <label class="afc-label">Sq Ft</label>
                <input type="number" name="_listing_sqft" value="<?php echo esc_attr($sqft); ?>" class="afc-input">
            </div>
        </div>
        <?php
    }

    public static function render_media_metabox( $post ) {
        $hero_id = C::get_meta( $post->ID, C::META_HERO_ID );
        $hero_url = $hero_id ? wp_get_attachment_image_url( $hero_id, 'medium' ) : '';
        $gallery_ids = C::get_meta( $post->ID, C::META_GALLERY_IDS ) ?: [];
        ?>
        <div class="afc-metabox-content">
            <div class="afc-media-row">
                <div class="afc-hero-box">
                    <label class="afc-label">Primary Asset Hero</label>
                    <div id="afc-hero-preview" class="afc-preview-square">
                        <?php if ($hero_url) : ?>
                            <img src="<?php echo esc_url($hero_url); ?>">
                            <span class="afc-remove-media" data-target="hero">×</span>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="_listing_hero_id" id="_listing_hero_id" value="<?php echo esc_attr($hero_id); ?>">
                    <button type="button" class="button afc-upload-trigger" data-type="hero">Assign Hero Image</button>
                </div>

                <div class="afc-gallery-box">
                    <label class="afc-label">Gallery Slider (Max 16)</label>
                    <div id="afc-gallery-sortable" class="afc-grid-gallery">
                        <?php foreach ( $gallery_ids as $id ) : 
                            $url = wp_get_attachment_image_url($id, 'thumbnail');
                            if ($url) echo "<div class='afc-thumb' data-id='{$id}'><img src='{$url}'><span class='afc-remove-media'>×</span></div>";
                        endforeach; ?>
                    </div>
                    <input type="hidden" name="_listing_gallery_ids" id="_listing_gallery_ids" value="<?php echo esc_attr(implode(',', (array)$gallery_ids)); ?>">
                    <button type="button" class="button afc-upload-trigger" data-type="gallery">Add Gallery Photos</button>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_location_metabox( $post ) {
        $address = C::get_meta($post->ID, C::META_ADDRESS);
        $lat = C::get_meta($post->ID, C::META_GPS_LAT);
        $lng = C::get_meta($post->ID, C::META_GPS_LNG);
        ?>
        <div class="afc-metabox-content afc-grid-location">
            <div class="afc-field">
                <label class="afc-label">📍 Street Address</label>
                <input type="text" name="_listing_address" value="<?php echo esc_attr($address); ?>" class="afc-input">
            </div>
            <div class="afc-field">
                <label class="afc-label">GPS Latitude</label>
                <input type="text" name="_gps_lat" value="<?php echo esc_attr($lat); ?>" class="afc-input">
            </div>
            <div class="afc-field">
                <label class="afc-label">GPS Longitude</label>
                <input type="text" name="_gps_lng" value="<?php echo esc_attr($lng); ?>" class="afc-input">
            </div>
        </div>
        <?php
    }

    public static function render_amenities_metabox( $post ) {
        $selected = (array) C::get_meta($post->ID, C::META_AMENITIES);
        $amenities = [
            'Gourmet Kitchen'=>'🍳','Infinity Pool'=>'🌊','Ocean View'=>'🌅','Wine Cellar'=>'🍷',
            'Private Gym'=>'🏋️','Smart Home Tech'=>'📱','Outdoor Cinema'=>'🎬','Helipad Access'=>'🚁',
            'Gated Community'=>'🏰','Guest House'=>'🏠','Solar Power'=>'☀️','Beach Front'=>'🏖️'
        ];
        ?>
        <div class="afc-metabox-content">
            <div class="afc-amenities-grid">
                <?php foreach ($amenities as $label=>$icon): ?>
                <label class="afc-amenity-chip">
                    <input type="checkbox" name="_listing_amenities[]" value="<?php echo $label; ?>" <?php checked(in_array($label, $selected)); ?>>
                    <span><?php echo $icon . ' ' . $label; ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    public static function render_agent_metabox( $post ) {
        $name = C::get_meta($post->ID, C::META_AGENT_NAME);
        $phone = C::get_meta($post->ID, C::META_AGENT_PHONE);
        $wa = C::get_meta($post->ID, C::META_SHOW_WA);
        ?>
        <div class="afc-metabox-content afc-grid-2">
            <div class="afc-field">
                <label class="afc-label">Listing Agent Name</label>
                <input type="text" name="_agent_name_display" value="<?php echo esc_attr($name); ?>" class="afc-input">
            </div>
            <div class="afc-field">
                <label class="afc-label">Contact Phone</label>
                <input type="text" name="_agent_phone_display" value="<?php echo esc_attr($phone); ?>" class="afc-input">
            </div>
            <div class="afc-field">
                <label><input type="checkbox" name="_show_floating_whatsapp" value="1" <?php checked($wa, '1'); ?>> Enable WhatsApp Integration</label>
            </div>
        </div>
        <?php
    }

    public static function render_intelligence_metabox( $post ) {
        $pdf_id = C::get_meta($post->ID, C::META_PDF_ID);
        $schedule = C::get_meta($post->ID, C::META_OPEN_HOUSE);
        ?>
        <div class="afc-metabox-content">
            <div class="afc-field">
                <label class="afc-label">📁 Asset Brochure (PDF)</label>
                <input type="hidden" name="_listing_pdf_id" id="_listing_pdf_id" value="<?php echo esc_attr($pdf_id); ?>">
                <button type="button" class="button afc-upload-trigger" data-type="pdf">Upload Document</button>
                <span id="pdf-status"><?php echo $pdf_id ? "File Attached (ID: $pdf_id)" : "No file selected"; ?></span>
            </div>
            <div class="afc-field">
                <label class="afc-label">🗓️ Private Showing Terms</label>
                <textarea name="_listing_showing_schedule" class="afc-input" rows="2"><?php echo esc_textarea($schedule); ?></textarea>
            </div>
        </div>
        <?php
    }

    public static function render_publish_metabox( $post ) {
        $status = $post->post_status;
        ?>
        <div class="afc-sidebar-controls">
            <div class="afc-field">
                <label class="afc-label">Market Status</label>
                <select name="_listing_market_status" class="afc-select-full">
                    <option value="publish" <?php selected($status, 'publish'); ?>>🟢 Active</option>
                    <option value="pending" <?php selected($status, 'pending'); ?>>🟡 Pending Review</option>
                    <option value="sold" <?php selected($status, 'sold'); ?>>🔴 Sold</option>
                    <option value="draft" <?php selected($status, 'draft'); ?>>⚪ Draft</option>
                </select>
            </div>
            <button type="submit" class="button button-primary button-large afc-full-width">Update Digital Asset</button>
            <div class="afc-sidebar-info">
                Last Updated: <strong><?php echo get_the_modified_date('M j, Y @ g:i a'); ?></strong>
            </div>
        </div>
        <?php
    }

    /* =========================================================
        SAVE LOGIC
    ========================================================= */
    public static function save_metaboxes($post_id, $post) {
        if ( ! isset($_POST['afc_listing_nonce']) || ! wp_verify_nonce($_POST['afc_listing_nonce'], C::NONCE_META) ) return;
        if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
        if ( ! current_user_can('edit_post', $post_id) ) return;

        $meta_fields = [
            '_listing_intro_text'      => 'sanitize_text_field',
            '_listing_narrative'       => 'wp_kses_post',
            '_listing_price'           => 'floatval',
            '_listing_beds'            => 'intval',
            '_listing_baths'           => 'floatval',
            '_listing_sqft'            => 'floatval',
            '_listing_address'         => 'sanitize_text_field',
            '_gps_lat'                 => 'sanitize_text_field',
            '_gps_lng'                 => 'sanitize_text_field',
            '_agent_name_display'      => 'sanitize_text_field',
            '_agent_phone_display'     => 'sanitize_text_field',
            '_listing_hero_id'         => 'intval',
            '_listing_pdf_id'          => 'intval',
            '_listing_showing_schedule' => 'sanitize_textarea_field',
            '_show_floating_whatsapp'  => 'sanitize_text_field'
        ];

        foreach ( $meta_fields as $key => $sanitizer ) {
            if ( isset($_POST[$key]) ) {
                $val = call_user_func($sanitizer, $_POST[$key]);
                C::update_meta($post_id, $key, $val);
                if ($key === '_listing_hero_id' && $val) set_post_thumbnail($post_id, $val);
            } else {
                if ($key === '_show_floating_whatsapp') delete_post_meta($post_id, C::META_SHOW_WA);
            }
        }

        // Gallery
        $gallery_ids = isset($_POST['_listing_gallery_ids']) ? array_filter(explode(',', $_POST['_listing_gallery_ids'])) : [];
        C::update_meta($post_id, C::META_GALLERY_IDS, array_slice($gallery_ids, 0, 16));

        // Amenities
        $amenities = isset($_POST['_listing_amenities']) ? (array)$_POST['_listing_amenities'] : [];
        C::update_meta($post_id, C::META_AMENITIES, array_map('sanitize_text_field', $amenities));

        // Status Update
        if ( isset($_POST['_listing_market_status']) ) {
            $new_status = $_POST['_listing_market_status'];
            if ( $new_status !== $post->post_status ) {
                remove_action( 'save_post', [ __CLASS__, 'save_metaboxes' ] );
                wp_update_post(['ID' => $post_id, 'post_status' => $new_status]);
                add_action( 'save_post', [ __CLASS__, 'save_metaboxes' ], 10, 2 );
            }
        }
    }

    public static function render_admin_notices() {
        if (isset($_GET['message']) && $_GET['message'] == '6') {
            echo '<div class="notice notice-success is-dismissible"><p>🚀 <strong>GLOBAL BROADCAST SUCCESSFUL:</strong> Asset is now live.</p></div>';
        }
    }
}
AFCGlide_Metaboxes::init();