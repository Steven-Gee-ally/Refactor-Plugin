<?php
/**
 * AFCGlide Listings v3 - Unified Luxury Backbone v8.0
 * Cinematic Hero + 16-Photo Filmstrip Edition
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

// 1. DATA HARVESTING
$post_id  = get_the_ID();
$price    = get_post_meta($post_id, '_listing_price', true);
$address  = get_post_meta($post_id, '_listing_address', true);
$hero_id  = get_post_meta($post_id, '_hero_image_id', true);
$beds     = get_post_meta($post_id, '_listing_beds', true); 
$baths    = get_post_meta($post_id, '_listing_baths', true); 
$sqft     = get_post_meta($post_id, '_listing_sqft', true);
$gallery  = get_post_meta($post_id, '_listing_gallery_ids', true) ?: [];
$amenities = get_post_meta($post_id, '_listing_amenities', true);
$showing   = get_post_meta($post_id, '_listing_showing_schedule', true);
$pdf_id    = get_post_meta($post_id, '_listing_pdf_id', true);
$pdf_url   = $pdf_id ? wp_get_attachment_url($pdf_id) : '';

// Agent Identity
$a_name   = get_post_meta($post_id, '_agent_name_display', true);
$a_phone  = get_post_meta($post_id, '_agent_phone_display', true);
$a_photo  = get_post_meta($post_id, '_agent_photo_id', true);
$a_img    = $a_photo ? wp_get_attachment_url($a_photo) : AFCG_URL . 'assets/images/placeholder-agent.png';
$clean_phone = preg_replace('/[^0-9]/', '', $a_phone);
?>

<div class="afcglide-wrapper">
    
    <section class="afc-cinematic-stage">
        <div class="afcglide-hero-main">
            <?php if($hero_id): 
                echo wp_get_attachment_image($hero_id, 'full', false, ['class' => 'afc-hero-img']); 
            else: ?>
                <div class="afc-placeholder-hero">ASSET PHOTOGRAPHY PENDING</div>
            <?php endif; ?>

            <div class="afcglide-price-badge">
                <?php echo $price ? '$' . number_format($price) : 'Contact for Price'; ?>
            </div>
        </div>

        <?php if(!empty($gallery)): ?>
        <div class="afc-filmstrip-wrapper">
            <div class="afc-filmstrip-container">
                <?php foreach($gallery as $img_id): ?>
                    <div class="afc-filmstrip-item">
                        <?php echo wp_get_attachment_image($img_id, 'large'); ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="afc-slider-controls">
                <button class="afc-slider-prev">←</button>
                <button class="afc-slider-next">→</button>
            </div>
        </div>
        <?php endif; ?>
    </section>

    <div class="afc-listing-grid">
        <main class="afc-main-column">
            <div class="afc-title-header">
                <h1><?php the_title(); ?></h1>
                <p class="afc-location-sub">📍 <?php echo esc_html($address); ?></p>
            </div>

            <div class="afcglide-specs-bar">
                <div class="afcglide-spec-item">
                    <label>BEDS</label>
                    <strong><?php echo esc_html($beds ?: '0'); ?></strong>
                </div>
                <div class="afcglide-spec-item">
                    <label>BATHS</label>
                    <strong><?php echo esc_html($baths ?: '0'); ?></strong>
                </div>
                <div class="afcglide-spec-item">
                    <label>SQ FT</label>
                    <strong><?php echo number_format($sqft); ?></strong>
                </div>
            </div>

            <?php if ( ! empty( $showing ) ) : ?>
            <div class="afc-showing-alert" style="background: #fff8e1; border-left: 5px solid #10b981; padding: 20px; border-radius: 12px; margin-bottom: 30px; display: flex; align-items: center; gap: 15px;">
                <span style="font-size: 24px;">🗓️</span>
                <div>
                    <strong style="display: block; font-size: 11px; text-transform: uppercase; color: #10b981; letter-spacing: 1px;">Upcoming Showing Schedule</strong>
                    <span style="font-size: 16px; font-weight: 700; color: #0f172a;"><?php echo esc_html( $showing ); ?></span>
                </div>
            </div>
            <?php endif; ?>

            <div class="afc-description-content">
                <h3 class="afc-section-header">Property Narrative</h3>
                <?php the_content(); ?>
            </div>

            <?php if ( ! empty( $amenities ) && is_array( $amenities ) ) : ?>
            <div class="afc-amenities-section">
                <h3 class="afc-section-header">Premium Asset Features</h3>
                <div class="afc-amenities-grid">
                    <?php foreach ( $amenities as $amenity ) : ?>
                        <div class="afc-amenity-pill">
                            <span class="afc-icon-check">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                            </span>
                            <span class="afc-amenity-label"><?php echo esc_html( $amenity ); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </main>

        <aside class="afc-sidebar-column">
            <div class="afcglide-agent-card">
                <div class="afc-agent-photo-wrap">
                    <img src="<?php echo esc_url($a_img); ?>" alt="Agent">
                </div>
                <h4 class="afc-agent-name"><?php echo esc_html($a_name); ?></h4>
                <p class="afc-agent-subtitle">Listing Specialist</p>
                
                <div class="afc-agent-actions">
                    <a href="tel:<?php echo $clean_phone; ?>" class="afc-btn-primary">SECURE SHOWING</a>
                    <a href="https://wa.me/<?php echo $clean_phone; ?>" class="afc-btn-primary" style="background: #0f172a;">WHATSAPP ENQUIRY</a>
                </div>

                <?php if ( $pdf_url ) : ?>
                <div class="afc-asset-files" style="margin-top: 20px;">
                    <a href="<?php echo esc_url( $pdf_url ); ?>" target="_blank" class="afc-btn-primary" style="background: #f1f5f9; color: #0f172a; border: 1px solid #e2e8f0; font-size: 11px;">
                        📄 DOWNLOAD FACT SHEET
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </aside>
    </div>
</div>

<?php 
$show_wa = get_post_meta(get_the_ID(), '_show_floating_whatsapp', true);
if ( $show_wa === '1' && !empty($clean_phone) ) : 
?>
<a href="https://wa.me/<?php echo $clean_phone; ?>" class="afc-whatsapp-float" target="_blank">
    <svg viewBox="0 0 32 32" class="afc-wa-icon"><path d="M16 0c-8.837 0-16 7.163-16 16 0 2.825.737 5.588 2.137 8.137l-2.137 7.863 8.1-.2.1.2c2.487 1.463 5.112 2.112 7.9 2.112 8.837 0 16-7.163 16-16s-7.163-16-16-16zm8.287 21.825c-.337.95-1.712 1.838-2.737 2.05-.688.138-1.588.25-4.6-1.013-3.862-1.612-6.362-5.538-6.55-5.8-.188-.262-1.525-2.025-1.525-3.862 0-1.838.963-2.738 1.3-3.113.337-.375.75-.463 1-.463s.5 0 .712.013c.225.013.525-.088.825.638.3.713 1.013 2.475 1.1 2.663.088.188.15.413.025.663-.125.263-.188.425-.375.65-.188.225-.412.513-.587.688-.2.2-.412.412-.175.812.238.4.1.863 2.087 2.625 1.637 1.45 3.012 1.9 3.437 2.113.425.213.675.175.925-.113.25-.288 1.075-1.25 1.362-1.688.3-.425.588-.363.988-.212.4.15 2.525 1.188 2.962 1.4.438.213.738.313.838.488.1.175.1.988-.237 1.938z" fill="currentColor"/></svg>
    <span class="afc-wa-tooltip">Direct Agent Line</span>
</a>
<?php endif; ?>

<div id="afc-success-overlay" class="afc-overlay-hidden">
    <div class="afc-overlay-content">
        <div class="afc-overlay-close" onclick="closeAfcOverlay()">×</div>
        <div class="afc-success-icon">✓</div>
        <h2>Request Initiated</h2>
        <p>The Listing Specialist has been notified. Your secure showing request is being prioritized.</p>
        <div class="afc-overlay-line"></div>
        <button class="afc-btn-primary" onclick="closeAfcOverlay()">Return to Asset</button>
    </div>
</div>

<?php get_footer(); ?>