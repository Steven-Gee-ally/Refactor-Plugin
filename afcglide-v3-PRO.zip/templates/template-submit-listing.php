<?php
/**
 * AFCGlide - Professional Agent Submission Form
 * Version 4.3.0 - Synergy Full-Structure Edition
 */

if ( ! defined( 'ABSPATH' ) ) exit;

use AFCGlide\Core\Constants as C;

// ... [Data Harvesting Logic stays exactly as you have it] ...
?>

<div id="afcglide-submission-root" class="afc-control-center">
    
    <form id="afcglide-front-submission" class="afc-modern-form" enctype="multipart/form-data">
        <?php wp_nonce_field('afc_listing_submit', 'afc_nonce'); ?>
        <input type="hidden" name="action" value="afc_handle_submission">
        <input type="hidden" name="post_id" value="<?php echo (int)$post_id; ?>">

        <fieldset <?php echo $is_locked ? 'disabled' : ''; ?>>
        
        <section class="afc-form-section">
            <h3 class="afc-section-title"><span class="afc-step-num">1</span> Asset Narrative</h3>
            <div class="afc-field full-width">
                <label>Internal Asset Title</label>
                <input type="text" name="listing_title" value="<?php echo esc_attr($defaults['title']); ?>" placeholder="e.g. Villa Mariposa Estate" required>
            </div>
            <div class="afc-field full-width">
                <label>Luxury Marketing Description</label>
                <textarea name="listing_description" rows="6" placeholder="Describe the lifestyle..."><?php echo esc_textarea($defaults['description']); ?></textarea>
            </div>
        </section>

        <section class="afc-form-section">
            <h3 class="afc-section-title"><span class="afc-step-num">2</span> Technical Specifications</h3>
            <div class="afc-flex-row">
                <div class="afc-field flex-2">
                    <label>List Price (USD)</label>
                    <input type="number" name="listing_price" value="<?php echo esc_attr($defaults['price']); ?>" placeholder="0.00" required>
                </div>
                <div class="afc-field flex-3">
                    <label>Core Metrics</label>
                    <div class="afc-triple-input">
                        <div class="afc-sub-field"><span>BEDS</span><input type="number" name="listing_beds" value="<?php echo esc_attr($defaults['beds']); ?>"></div>
                        <div class="afc-sub-field"><span>BATHS</span><input type="number" name="listing_baths" value="<?php echo esc_attr($defaults['baths']); ?>" step="0.5"></div>
                        <div class="afc-sub-field"><span>SQ FT</span><input type="number" name="listing_sqft" value="<?php echo esc_attr($defaults['sqft']); ?>"></div>
                    </div>
                </div>
            </div>
        </section>

        <section class="afc-form-section">
            <h3 class="afc-section-title"><span class="afc-step-num">3</span> Visual Assets</h3>
            <div class="afc-media-uploader" id="afc-drag-drop-zone">
                <div class="afc-media-prompt">
                    <div class="afc-upload-icon">📸</div>
                    <p>Drag & Drop High-Resolution Imagery</p>
                </div>
                <input type="file" name="listing_images[]" id="afc_image_input" multiple accept="image/*" style="display:none;">
                <button type="button" class="afc-select-files" onclick="document.getElementById('afc_image_input').click();">SELECT FILES</button>
            </div>
            <div id="afc-media-preview-grid" class="afc-preview-grid"></div>
        </section>

        <section class="afc-form-section">
            <h3 class="afc-section-title"><span class="afc-step-num">4</span> Geospatial Identity</h3>
            <div class="afc-field full-width">
                <label>📍 Physical Address</label>
                <input type="text" name="listing_address" id="afc_location_autocomplete" value="<?php echo esc_attr($defaults['address']); ?>" placeholder="Enter street address...">
            </div>
            <div class="afc-flex-row afc-gps-box">
                <div class="afc-field">
                    <label>📡 LATITUDE</label>
                    <input type="text" name="gps_lat" value="<?php echo esc_attr($defaults['gps_lat']); ?>" readonly>
                </div>
                <div class="afc-field">
                    <label>📡 LONGITUDE</label>
                    <input type="text" name="gps_lng" value="<?php echo esc_attr($defaults['gps_lng']); ?>" readonly>
                </div>
            </div>
        </section>

        <section class="afc-form-section">
            <h3 class="afc-section-title"><span class="afc-step-num">5</span> Market Status</h3>
            <div class="afc-status-toggle">
                <?php 
                $statuses = ['active' => 'Active', 'pending' => 'Pending', 'sold' => 'Sold'];
                foreach ($statuses as $val => $label) : 
                    $checked = ($defaults['status'] === $val) ? 'checked' : '';
                ?>
                <label class="status-opt">
                    <input type="radio" name="listing_status" value="<?php echo $val; ?>" <?php echo $checked; ?>>
                    <span class="status-label <?php echo $val; ?>"><?php echo $label; ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="afc-form-section">
            <h3 class="afc-section-title"><span class="afc-step-num">6</span> Property Features</h3>
            <div class="amenities-container">
                <?php 
                $features = ['Pool', 'Gym', 'Wine Cellar', 'Home Theater', 'Smart Home', 'Gated', 'Waterfront', 'Guest House'];
                $saved_features = get_post_meta($post_id, '_listing_features', true) ?: [];
                foreach ($features as $feature) : 
                    $is_checked = in_array($feature, (array)$saved_features) ? 'checked' : '';
                ?>
                <label class="afc-checkbox-item">
                    <input type="checkbox" name="listing_features[]" value="<?php echo $feature; ?>" <?php echo $is_checked; ?>>
                    <span><?php echo $feature; ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </section>

        </fieldset>

        <div class="afc-form-actions">
            <button type="submit" id="afc-submit-btn" class="afc-main-submit">
                <?php echo $is_locked ? '🔒 SYSTEM OFFLINE' : ($post_id ? 'SYNC ASSET UPDATES' : 'PUBLISH GLOBAL LISTING'); ?>
            </button>
            <div id="afc-form-feedback"></div>
        </div>
        
    </form>
</div>